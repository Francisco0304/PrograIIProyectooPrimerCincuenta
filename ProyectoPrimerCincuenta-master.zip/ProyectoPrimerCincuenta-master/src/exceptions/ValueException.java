package exceptions;

public class ValueException extends Exception {

    public ValueException(String message) {
        super(message);
    }
}