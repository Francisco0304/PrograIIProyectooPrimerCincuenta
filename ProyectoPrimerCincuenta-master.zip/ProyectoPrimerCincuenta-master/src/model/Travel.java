package model;

public class Travel {
}
